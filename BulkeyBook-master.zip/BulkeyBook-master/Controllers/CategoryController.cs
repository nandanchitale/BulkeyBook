﻿using BulkyBook.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using UdemyCourseBulkyBook.Data;
using System.ComponentModel.DataAnnotations.Schema;


namespace BulkyBook.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _db;

        public CategoryController(ApplicationDbContext _db)
        {
            this._db = _db;
        }
        public IActionResult Index()
        {
            IEnumerable<Category> objCategoryList = this._db.Categories.ToList();
            return View(objCategoryList);
        }


        /**
         *  Add / View Category
         */

        // GET
        public IActionResult Create()
        {
            return View();
        }

        // POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category obj)
        {
            if (ModelState.IsValid)
            {
                this._db.Categories.Add(obj);
                this._db.SaveChanges();
                TempData["success"] = "Category created successfully";
                return RedirectToAction("Index");
            }
            return View(obj);
        }

        /**
         *  Edit / View Category
         */

        // GET
        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
                return NotFound();
            var categoryFromDb = _db.Categories.Find(id);
            if (categoryFromDb != null)
                return View(categoryFromDb);
            else
                return NotFound();
        }

        // POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Category obj)
        {
            if (ModelState.IsValid)
            {
                this._db.Categories.Update(obj);
                this._db.SaveChanges();
                TempData["success"] = "Category Edited successfully";
                return RedirectToAction("Index");
            }
            return View(obj);
        }

        /**
         *  Delete / View Category
         */

        // GET
        public IActionResult Remove(int? id)
        {
            if (id == null || id == 0)
                return NotFound();
            var categoryFromDb = _db.Categories.Find(id);
            if (categoryFromDb != null)
                return View(categoryFromDb);
            else
                return NotFound();
        }

        // POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RemoveCategory(int? id)
        {
            var categoryFromDb = _db.Categories.Find(id);

            if (categoryFromDb is null)
                return NotFound();

            this._db.Categories.Remove(categoryFromDb);
            this._db.SaveChanges();
            TempData["success"] = "Category removed successfully";
            return RedirectToAction("Index");
        }
    }
}
